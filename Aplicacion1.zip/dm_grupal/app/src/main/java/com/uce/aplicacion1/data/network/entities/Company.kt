package com.uce.aplicacion1.data.network.entities

data class Company(
    val bs: String ?,
    val catchPhrase: String ?,
    val name: String ?
)