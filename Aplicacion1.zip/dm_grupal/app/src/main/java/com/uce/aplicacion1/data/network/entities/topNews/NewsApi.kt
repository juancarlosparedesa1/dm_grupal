package com.uce.aplicacion1.data.network.entities.topNews

data class NewsApi(
    val `data`: List<Data>,
    val meta: Meta
)