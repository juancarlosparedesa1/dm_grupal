package com.uce.aplicacion1.data.network.entities.clash.player

data class IconUrlsX(
    val medium: String
)