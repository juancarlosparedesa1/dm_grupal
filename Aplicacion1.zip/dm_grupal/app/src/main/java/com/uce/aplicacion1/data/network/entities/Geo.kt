package com.uce.aplicacion1.data.network.entities

data class Geo(
    val lat: String ?,
    val lng: String ?
)