package com.uce.aplicacion1.data.network.entities.clash.player

data class IconUrls(
    val evolutionMedium: String,
    val medium: String
)