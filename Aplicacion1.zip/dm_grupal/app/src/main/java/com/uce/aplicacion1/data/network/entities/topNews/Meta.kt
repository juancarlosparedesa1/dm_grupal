package com.uce.aplicacion1.data.network.entities.topNews

data class Meta(
    val found: Int,
    val limit: Int,
    val page: Int,
    val returned: Int
)