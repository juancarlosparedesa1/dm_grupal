package com.uce.aplicacion1.data.network.entities.clash.cards

data class IconUrls(
    val evolutionMedium: String,
    val medium: String
)