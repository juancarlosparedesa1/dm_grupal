package com.uce.aplicacion1.data.network.entities.clash.cards

data class IconUrlsX(
    val medium: String
)