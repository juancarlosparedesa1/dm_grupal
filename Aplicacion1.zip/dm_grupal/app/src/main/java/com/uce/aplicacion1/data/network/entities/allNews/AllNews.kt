package com.uce.aplicacion1.data.network.entities.allNews

data class AllNews(
    val `data`: List<Data>,
    val meta: Meta
)