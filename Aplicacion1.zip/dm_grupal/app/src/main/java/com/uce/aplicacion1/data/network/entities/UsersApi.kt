package com.uce.aplicacion1.data.network.entities

data class UsersApi (
    val users: List<UsersApiItem>
)